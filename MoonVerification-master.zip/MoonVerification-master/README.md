# MoonVerification
Репозиторий для тестового задания Unity Developer
Пожалуйста сделайте форк репозитория и работайте в нем.

Задание: https://docs.google.com/document/d/1zb5RxBtJPI5rC8qTiQQ5pL4IFFz_HcrV8SoJyalf4VQ/edit#heading=h.o0c5rckzzdff

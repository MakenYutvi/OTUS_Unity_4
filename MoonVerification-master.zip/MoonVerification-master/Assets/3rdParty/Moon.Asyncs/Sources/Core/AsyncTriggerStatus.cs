﻿namespace Moon.Asyncs
{
    public class AsyncTriggerStatus
    {
        public bool complete = false;
    }
}
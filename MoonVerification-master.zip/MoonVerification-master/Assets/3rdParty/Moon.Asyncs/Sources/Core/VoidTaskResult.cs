﻿namespace Moon.Asyncs
{
    public struct VoidTaskResult
    {
        public static VoidTaskResult Empty = new VoidTaskResult();
    }
}
﻿namespace Moon.Asyncs.Internal.Commands
{
    internal enum AsyncCommandResult
    {
        None,
        Ok,
        Exception
    }
}
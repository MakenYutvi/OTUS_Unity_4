﻿public enum CardType
{
    Animals,
    Clothes,
    Form,
    Furniture,
    Products,
}
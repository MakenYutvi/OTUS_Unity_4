﻿using System;


namespace Core
{
    public interface IPartUI
    {
        Type Type { get; }
    }
}

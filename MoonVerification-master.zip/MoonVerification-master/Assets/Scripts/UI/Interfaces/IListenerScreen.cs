﻿namespace Core
{
    public interface IListenerScreen
    {
        void ShowScreen();
        void HideScreen();
    }
}

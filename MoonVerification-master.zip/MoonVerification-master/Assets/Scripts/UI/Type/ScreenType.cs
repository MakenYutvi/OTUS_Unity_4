﻿namespace Core
{
    public enum ScreenType
    {
        None      = 0,
        MainMenu  = 1,
        GameMenu  = 2,
        Settings  = 3,
        RestartMenu = 4
    }
}

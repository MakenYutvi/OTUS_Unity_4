﻿namespace Core
{
    public enum ScreenElementType
    {
        None      = 0
    }
}

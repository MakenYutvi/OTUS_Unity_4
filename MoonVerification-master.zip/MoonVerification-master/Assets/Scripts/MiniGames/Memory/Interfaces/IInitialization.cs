﻿namespace Core
{
    public interface IInitialization
    {
        void Initialization();
    }
}

